# src/email_validator/__init__.py
from sku_validator.validator import is_valid_sku

__all__ = ["is_valid_sku"]