    # src/email_validator/validator.py
"""Валидация sku"""
import re

_SKU_RE = re.compile(
    r"(?:SKU|артикул)[:\s]+([A-Z0-9]+(?:-[A-Z0-9]+)*)"
)

def is_valid_sku(text: str) -> bool:
    """Проверяет, является ли строка синтаксически корректным sku/артикулом"""
    if not isinstance(text, str):
        return False
    if not text:
        return False
    return _SKU_RE.search(text) is not None