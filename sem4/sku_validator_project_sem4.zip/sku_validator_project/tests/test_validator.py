# tests/test_validator.py
import pytest

from sku_validator import is_valid_sku



# ---------- Тесты через фикстуры из conftest.py ----------
def test_all_valid_fixture_sku(valid_sku):
    for sku in valid_sku:
        assert is_valid_sku(sku) is True, f"должен быть валидным: r{sku!r}"


def test_all_invalid_fixture_sku(invalid_sku):
    for sku in invalid_sku:
        assert is_valid_sku(sku) is False, f"должен быть невалидным: {sku!r}"


