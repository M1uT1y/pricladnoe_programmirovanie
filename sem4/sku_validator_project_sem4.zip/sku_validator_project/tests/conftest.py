# tests/conftest.py
import pytest


@pytest.fixture(scope="session")
def valid_sku() -> list[str]:
    """Набор синтаксически корректных sku"""
    return [
        "SKU: KB-9901",
        "SKU KB-9902",
        "SKU:7788-XZ",
        "артикул MX-4450-BLK",
        "артикул: MX-4451-WHT",
        "артикул  PL-1029-RED",
        "SKU: A1B2C3",
        "SKU: 7788",
        "SKU: ABC",
        "заказ A-10234, SKU: KB-9901",
        "SKU: KB-9901, артикул MX-4450-BLK",
        ]


@pytest.fixture(scope="session")
def invalid_sku() -> list[str]:
    """Набор заведомо некорректных sku"""
    return [
        "",
        "SKU: KB-",
        "SKU: KB--9901",
        "SKU: kb-9901",
        "SKU: КВ-9901",
        "SKU: KB 9901",
        "SKU: KB_9901",
        "SKU: KB.9901",
        "SKU: KB/9901",
        "SKU:KB9901extra",
        "sku: KB-9901",
    ]